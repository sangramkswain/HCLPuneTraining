package baseTestClass;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pagesMYHCL.MyHCLLoginPage;

public class MyHCLBaseTestClass {
	public MyHCLLoginPage obj_MyHCLLoginPage;
	public WebDriver driver;
	public ExtentReports extent ;
	public ExtentTest log;
	
	@BeforeTest
	public void beforeTest() {
		
		extent = new ExtentReports("D:\\Users\\sangram.swain\\eclipse-workspace\\PageObjectModel\\Report\\TestReport.html");
		extent.loadConfig(new File("D:\\Users\\sangram.swain\\eclipse-workspace\\PageObjectModel\\Resource\\extent-config.xml"));
		extent.addSystemInfo("Project", "HCL Automation");
		
		
	}
	
	/*@AfterTest
	 public void failTests(ITestResult result) {
		 if(result.getStatus()==ITestResult.FAILURE) {
			  log.log(LogStatus.FAIL, "Test Case failed");
		  }
		  
		  extent.endTest(log);
		  extent.flush();
	}*/

	@BeforeMethod
	public void intiTestSuite() {
		driver = new FirefoxDriver();
		driver.get("https://www.myhcl.com/Login/home.aspx");
		obj_MyHCLLoginPage = PageFactory.initElements(driver, MyHCLLoginPage.class);
	}

	@AfterMethod
	public void cleanUP() {
		driver.quit();
	}

}
