package testMyHCLHomePage;

import org.testng.Assert;
import org.testng.annotations.Test;

import baseTestClass.MyHCLBaseTestClass;
import pagesMYHCL.myHCLHomePage;

public class test_HomePageTitleCheck extends MyHCLBaseTestClass {
	myHCLHomePage obj_myHCLHomePage;

	@Test
	public void testHomePageTitle() throws Exception {

		obj_myHCLHomePage = obj_MyHCLLoginPage.navigateToHomePage(driver);

		boolean result = obj_myHCLHomePage.verifyHomePageTitle(driver);

		Assert.assertTrue(result);

	}

}
