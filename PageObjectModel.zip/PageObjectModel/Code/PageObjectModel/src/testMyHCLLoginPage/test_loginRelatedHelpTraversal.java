package testMyHCLLoginPage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import baseTestClass.MyHCLBaseTestClass;
import utilityMYHCL.MyHCL_Utility;

public class test_loginRelatedHelpTraversal extends MyHCLBaseTestClass {
	@Test
	public void testLoginScreenTraversal() throws IOException {
		
		boolean result = obj_MyHCLLoginPage.loginHelpScreenTraversal(driver);
		
		Assert.assertTrue(result);
		System.out.println("testLoginScreenTraversal");
		
		
		
	}
	

}
