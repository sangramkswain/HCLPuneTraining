package testMyHCLLoginPage;

import org.testng.Assert;
import org.testng.annotations.Test;

import baseTestClass.MyHCLBaseTestClass;

public class test_loginPageTitle extends MyHCLBaseTestClass {
	@Test
	public void testHomePageTitle(){
		
		boolean result = obj_MyHCLLoginPage.verifyLoginPageTitle(driver);
		
		Assert.assertTrue(result);
		
		
	}
	
	
}
