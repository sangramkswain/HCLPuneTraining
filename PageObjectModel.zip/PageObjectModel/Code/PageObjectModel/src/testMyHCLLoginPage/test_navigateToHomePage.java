package testMyHCLLoginPage;

import org.testng.Assert;
import org.testng.annotations.Test;

import baseTestClass.MyHCLBaseTestClass;
import pagesMYHCL.myHCLHomePage;

public class test_navigateToHomePage extends MyHCLBaseTestClass {
	@Test
	public void testNavigateToHomePage() throws Exception {
		myHCLHomePage obj_myHCLHomePage;
		
		obj_myHCLHomePage = obj_MyHCLLoginPage.navigateToHomePage(driver);
		
		boolean result = ((obj_myHCLHomePage.verifyHomePageTitle(driver))
				&& (obj_myHCLHomePage.verifyHomePageTitle(driver)));

		Assert.assertTrue(result);
		
	}
	
		
}
