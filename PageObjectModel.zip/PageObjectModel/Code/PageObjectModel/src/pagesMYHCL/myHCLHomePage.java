package pagesMYHCL;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import utilityMYHCL.MyHCL_Utility;

public class myHCLHomePage {

	@FindBy(linkText = "Home")
	WebElement home_WE;

	@FindBy(xpath = "//a[contains(text(),'App Central')]")
	WebElement appCentral_WE;

	@FindBy(linkText = "HR Studio")
	WebElement hrStudio_WE;

	public boolean verifyHomePageTitle(WebDriver driver) {
		String actualTitle = "My HCL";
		return (MyHCL_Utility.validateWindowTitle(driver, actualTitle));

	}

	public boolean verifyHomePageLoading(WebDriver driver) {
		boolean result = true;

		ArrayList<WebElement> menuList = new ArrayList<WebElement>();

		menuList.add(home_WE);
		menuList.add(appCentral_WE);
		menuList.add(hrStudio_WE);

		for (int i = 0; i < menuList.size(); i++) {
			result = MyHCL_Utility.checkElementPresence(driver, menuList.get(i), 20);
			if (result == false)
				break;
		}

		return result;
	}

}
