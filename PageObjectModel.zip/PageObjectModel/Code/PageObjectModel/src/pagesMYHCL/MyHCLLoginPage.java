package pagesMYHCL;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilityMYHCL.MyHCL_Utility;

public class MyHCLLoginPage {
	WebDriver driver;

	@FindBy(xpath = ".//*[@id='txtUserID']")
	WebElement userID_WE;

	@FindBy(xpath = ".//*[@id='txtPassword']")
	WebElement password_WE;

	@FindBy(xpath = ".//*[@id='ddlDomain']")
	WebElement domain_WE;

	@FindBy(xpath = ".//*[@id='btnSubmit']")
	WebElement loginButton_WE;

	@FindBy(partialLinkText = "Forgot")
	WebElement link_FRPassword_WE;

	@FindBy(linkText = "Login Help")
	WebElement link_LoginHelp_WE;

	public MyHCLLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public boolean verifyLoginPageTitle(WebDriver driver) {

		String expectedTitle = "My HCL Login";
		return (MyHCL_Utility.validateWindowTitle(driver, expectedTitle));
	}

	public boolean verifyLoginPageLoading(WebDriver driver) {
		boolean result = true;

		ArrayList<WebElement> menuList = new ArrayList<WebElement>();

		menuList.add(userID_WE);
		menuList.add(password_WE);
		menuList.add(domain_WE);
		menuList.add(loginButton_WE);
		menuList.add(link_LoginHelp_WE);
		menuList.add(link_FRPassword_WE);

		for (int i = 0; i < menuList.size(); i++) {
			result = MyHCL_Utility.checkElementPresence(driver, menuList.get(i), 40);

			if (result == false)
				break;
		}
		return result;
	}

	public boolean loginHelpScreenTraversal(WebDriver driver) {
		boolean result = false;

		link_LoginHelp_WE.click();
		for (String handles : driver.getWindowHandles()) {
			driver.switchTo().window(handles);

			if ((driver.getTitle()).equals("Login Related Help")) {
				result = true;
				break;
			}
		}

		return result;
	}

	public myHCLHomePage navigateToHomePage(WebDriver driver) {
		userID_WE.sendKeys("Sangram.Swain"); // change it
		password_WE.sendKeys("@123"); // change it
		domain_WE.sendKeys("HCLTECH");
		loginButton_WE.click();
		
		//Added for the intermediate page to skip it
		driver.findElement(By.xpath(".//*[@id='btnskipndcontinue']")).click();

		myHCLHomePage obj_myHCLHomePage;
		obj_myHCLHomePage = PageFactory.initElements(driver, myHCLHomePage.class);

		return obj_myHCLHomePage;
	}

}
