package XMLParam;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class xmlParameterization {
	public String uID;
	public String pWD;

	@Test
	@Parameters({ "adminUserID", "adminPassword" })

	public void getCredentials(String userID, String passWord) {
		System.out.println(userID);
		uID = userID;
		pWD = passWord;

		System.out.println(passWord);
	}

	@Test
	public void login() {

		System.out.println("Value of user id = " + uID);
	}

}
