package globalParamProp;

import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;

public class globalPrmProp {

	public WebDriver driver;
	String userName;
	String passWord;
	String url_MyHCL;

	@Test
	public void loginToMyHCL() throws Exception {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				"D:\\Users\\sangram.swain\\eclipse-workspace\\TestNGGlobalParamProperties\\param.properties");
		prop.load(fis);

		userName = prop.getProperty("username");
		passWord = prop.getProperty("password");

		url_MyHCL = prop.getProperty("url");
		driver.get(url_MyHCL);
		driver.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys(userName);
		driver.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys(passWord);

	}

	@BeforeTest
	public void intiBrowser() {
		driver = new FirefoxDriver();
	}

}
