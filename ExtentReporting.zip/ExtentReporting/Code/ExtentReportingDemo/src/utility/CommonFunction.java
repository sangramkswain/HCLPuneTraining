package utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CommonFunction {
	
	public static String captureScreenShotAndGetPath(WebDriver driver, String screenshotName) throws IOException {
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String fotoPath ="D:\\Users\\sangram.swain\\eclipse-workspace\\ExtentReportingDemo\\ScreenShotFolder\\"+screenshotName+".png";
		FileUtils.copyFile(srcFile, new File (fotoPath));
		return fotoPath;
	}

}
